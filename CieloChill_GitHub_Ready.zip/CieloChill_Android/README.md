# Cielo Chill

Simulador atmosférico interactivo en HTML, JavaScript y WebGL 2, empaquetado como aplicación Android mediante WebView.

## Características
- Cielo procedural y nubes dinámicas.
- Océano animado con reflejos atmosféricos.
- Sistemas meteorológicos y fenómenos de tormenta.
- Controles táctiles para explorar la escena.
- Menú inicial renovado y pantalla de carga animada.
- Proyecto Android en pantalla completa y orientación horizontal.

## Ejecutar en navegador
Abre `app/src/main/assets/index.html` en un navegador compatible con WebGL 2 o sírvelo desde un servidor local.

## Compilar para Android
1. Instala Android Studio y el SDK de Android.
2. Abre esta carpeta en Android Studio.
3. Espera a que Gradle sincronice.
4. Selecciona **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

El APK de depuración se generará en `app/build/outputs/apk/debug/app-debug.apk`.

## Requisitos
- Android Studio compatible con Android Gradle Plugin 8.7.3.
- Android SDK Platform 35.
- Java 17.
- Android 6.0 (API 23) o superior.

## Nota
El simulador usa WebGL 2; el rendimiento y la compatibilidad dependen del navegador WebView y de la GPU del dispositivo.
